import sys, os, json, subprocess, statistics, re, platform
from pathlib import Path
root=Path('/Users/amaterasu/Vibranium/ash')
sys.path.insert(0,str(root/'scripts'))
import ash_bench as bench
import bench_tree_fusion as fusion
binary=root/'target/release/ash'
out=Path('/tmp/ash-tree-rollout-measure');out.mkdir(exist_ok=True)
cases=[('fib','bench_fib.hl','102334155',{}),('fib_calls','bench_fib.hl','102334155',{'ASH_NO_PURE_CSE':'1'}),('mandelbrot','test_mandelbrot.hl','112798587',{}),('deltablue','bench_deltablue.hl','14065400',{}),('arrays','bench_array_access.hl','-1737346944',{}),('simd','bench_simd_dot.hl','73726218',{}),('dispatch','bench_dyn_dispatch.hl',None,{}),('startup','test_tree_fusion_refusals.hl',None,{})]
record={'source':'local macOS; not CI evidence','base_revision':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'system':bench.system_info(),'binary_sha256':fusion.digest(binary),'source_changes':{},'method':'Same release binary, default hybrid, --no-tree-fusion versus default; one warmup pair, seven alternating pairs, two diagnostic pairs. Clean timing has no ASH diagnostics. Diagnostic phases/RSS are separate; no performance threshold on noisy local hardware.','cases':[]}
for f in subprocess.check_output(['git','diff','--name-only'],cwd=root,text=True).splitlines(): record['source_changes'][f]=fusion.digest(root/f)
for name,file,checksum,extra in cases:
 case={'name':name,'input':file,'sha256':fusion.digest(root/'crates/ash/test/tests'/file),'expected_numeric_checksum':checksum,'runs':[]};record['cases'].append(case)
 oracle=None
 for phase,count in [('warmup',1),('timing',7),('diagnostic',2)]:
  for pair in range(count):
   for variant in fusion.order(pair):
    diagnostic=phase=='diagnostic'
    cmd=[str(binary),'--quiet']+(['--no-tree-fusion'] if variant=='off' else [])
    if diagnostic:cmd+=['--tree-fusion-log']
    cmd+=[str(root/'crates/ash/test/tests'/file)]
    env=fusion.environment();env.update(extra)
    if diagnostic:env.update(ASH_PROFILE='phases',ASH_AIR_CACHE_STATS='1');cmd=bench.time_wrapper()+cmd
    result=bench.exec_run(cmd,root,env,120)
    if not result.ok:raise RuntimeError((name,variant,result))
    if checksum is not None and checksum not in re.findall(r'-?\d+',result.stdout):raise RuntimeError((name,'wrong checksum',result.stdout))
    if oracle is None:oracle=result.stdout
    if result.stdout!=oracle:raise RuntimeError((name,'parity',result.stdout,oracle))
    run={'phase':phase,'pair':pair,'variant':variant,'command':cmd,'environment':{k:v for k,v in env.items() if k.startswith('ASH_')},'wall_ms':result.wall_ms,'stdout':result.stdout,'stderr':result.stderr}
    if diagnostic:run.update(phases=fusion.phases(result.stderr),peak_rss_bytes=bench.parse_rss_bytes(result.stderr),fusion_report=[l for l in result.stderr.splitlines() if l.startswith('[tree-fusion]')])
    case['runs'].append(run)
  (out/'result.json').write_text(json.dumps(record,indent=2)+'\n')
 case['median_ms']={v:statistics.median(r['wall_ms'] for r in case['runs'] if r['phase']=='timing' and r['variant']==v) for v in ['off','on']}
 print(name,case['median_ms'],flush=True)
record['status']='PASS'
assert fusion.digest(binary)==record['binary_sha256']
(out/'result.json').write_text(json.dumps(record,indent=2)+'\n')

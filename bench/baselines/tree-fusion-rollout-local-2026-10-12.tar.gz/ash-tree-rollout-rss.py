exec(open('/tmp/ash-tree-rollout-measure.py').read().split('for name,file,checksum,extra in cases:')[0])
record['method']='Follow-up: five alternating diagnostic pairs for the dispatch RSS outlier; default allocator, phases, AIR cache statistics, GC statistics; no clean timing claim.'
record['runs']=[]
for pair in range(5):
 for variant in fusion.order(pair):
  env=fusion.environment();env.update(ASH_PROFILE='phases',ASH_AIR_CACHE_STATS='1',ASH_GC_STATS='1')
  cmd=bench.time_wrapper()+[str(binary),'--quiet','--tree-fusion-log']+(['--no-tree-fusion'] if variant=='off' else [])+[str(root/'crates/ash/test/tests/bench_dyn_dispatch.hl')]
  r=bench.exec_run(cmd,root,env,120)
  assert r.ok
  record['runs'].append({'pair':pair,'variant':variant,'command':cmd,'stdout':r.stdout,'stderr':r.stderr,'gc':bench.parse_gc(r.stderr),'peak_rss_bytes':bench.parse_rss_bytes(r.stderr)})
  print(pair,variant,round(bench.parse_rss_bytes(r.stderr)/2**20,1),bench.parse_gc(r.stderr),flush=True)
assert len(set(r['stdout'] for r in record['runs']))==1
record['status']='PASS'
(out/'rss-followup.json').write_text(json.dumps(record,indent=2)+'\n')
